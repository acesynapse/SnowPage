<?php

namespace Pusher\Storage;

use Exception;

class PushToDeployFailed extends Exception
{
}
