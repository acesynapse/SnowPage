<?php

namespace Pusher\Storage;

use Exception;

class PluginNotFound extends Exception
{
}
